package inf008.ecomerce.dealz;

public interface IMenu {
    void showMenu();
}
